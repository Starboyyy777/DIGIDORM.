// DIGIDORM — shared client-side behaviour

document.addEventListener("DOMContentLoaded", function () {
  // ---- Dark mode toggle ----
  const toggle = document.getElementById("darkModeToggle");
  const root = document.body;
  const stored = localStorage.getItem("digidorm-theme");
  if (stored === "dark") root.classList.add("dark-mode");
  if (toggle) {
    toggle.checked = root.classList.contains("dark-mode");
    toggle.addEventListener("change", function () {
      root.classList.toggle("dark-mode", toggle.checked);
      localStorage.setItem("digidorm-theme", toggle.checked ? "dark" : "light");
    });
  }

  // ---- Auto-dismiss alerts ----
  document.querySelectorAll(".alert").forEach(function (el) {
    setTimeout(function () {
      el.classList.remove("show");
      el.classList.add("fade");
    }, 4500);
  });

  // ---- Star rating widget (reviews form) ----
  const stars = document.querySelectorAll(".star-input i");
  const ratingField = document.getElementById("ratingValue");
  stars.forEach(function (star) {
    star.addEventListener("click", function () {
      const val = star.dataset.value;
      ratingField.value = val;
      stars.forEach(function (s) {
        s.classList.toggle("bi-star-fill", s.dataset.value <= val);
        s.classList.toggle("bi-star", s.dataset.value > val);
      });
    });
  });

  // ---- Live client-side search (admin student table) ----
  const liveSearch = document.getElementById("liveSearch");
  if (liveSearch) {
    liveSearch.addEventListener("input", function () {
      const term = liveSearch.value.toLowerCase();
      document.querySelectorAll("[data-search-row]").forEach(function (row) {
        row.style.display = row.innerText.toLowerCase().includes(term) ? "" : "none";
      });
    });
  }

  // ---- Confirm destructive actions ----
  document.querySelectorAll("[data-confirm]").forEach(function (el) {
    el.addEventListener("submit", function (e) {
      if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
  });
});
