-- ============================================================
-- DIGIDORM — College Hostel Management System
-- Database schema + sample data
-- Import via phpMyAdmin (XAMPP) or:  mysql -u root -p < hostel.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS hostel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hostel;

-- ------------------------------------------------------------
-- ROOM
-- ------------------------------------------------------------
CREATE TABLE room (
    room_id     INT AUTO_INCREMENT PRIMARY KEY,
    room_no     VARCHAR(10)  NOT NULL,
    block       VARCHAR(20)  NOT NULL,
    room_type   VARCHAR(20)  NOT NULL DEFAULT 'Shared',   -- Single / Double / Shared
    capacity    INT          NOT NULL DEFAULT 2,
    occupied    INT          NOT NULL DEFAULT 0,
    available   INT GENERATED ALWAYS AS (capacity - occupied) STORED,
    UNIQUE KEY uq_room (room_no, block)
);

-- ------------------------------------------------------------
-- STUDENT  (login = email/roll_no + password)
-- ------------------------------------------------------------
CREATE TABLE student (
    student_id   INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    roll_no      VARCHAR(30)  NOT NULL UNIQUE,
    branch       VARCHAR(50),
    year         VARCHAR(10),
    gender       VARCHAR(10),
    phone        VARCHAR(15),
    email        VARCHAR(100) NOT NULL UNIQUE,
    password     VARCHAR(255) NOT NULL,   -- hashed
    room_id      INT NULL,
    hostel_block VARCHAR(20),
    photo        VARCHAR(255),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE SET NULL
);

-- ------------------------------------------------------------
-- ADMIN
-- ------------------------------------------------------------
CREATE TABLE admin (
    admin_id  INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    username  VARCHAR(50)  NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL   -- hashed
);

-- ------------------------------------------------------------
-- WARDEN
-- ------------------------------------------------------------
CREATE TABLE warden (
    warden_id INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    username  VARCHAR(50)  NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,   -- hashed
    block     VARCHAR(20)
);

-- ------------------------------------------------------------
-- COMPLAINT
-- ------------------------------------------------------------
CREATE TABLE complaint (
    complaint_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    title        VARCHAR(150) NOT NULL,
    description  TEXT,
    category     VARCHAR(50) DEFAULT 'General',
    status       ENUM('Pending','In Progress','Resolved') DEFAULT 'Pending',
    date         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- FEE
-- ------------------------------------------------------------
CREATE TABLE fee (
    fee_id         INT AUTO_INCREMENT PRIMARY KEY,
    student_id     INT NOT NULL,
    amount         DECIMAL(10,2) NOT NULL,
    payment_date   DATE NULL,
    payment_status ENUM('Paid','Unpaid','Pending') DEFAULT 'Unpaid',
    receipt        VARCHAR(255),
    remarks        VARCHAR(255),
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- LEAVE
-- ------------------------------------------------------------
CREATE TABLE leave_application (
    leave_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    from_date  DATE NOT NULL,
    to_date    DATE NOT NULL,
    reason     TEXT,
    status     ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    applied_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- NOTICE
-- ------------------------------------------------------------
CREATE TABLE notice (
    notice_id   INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(150) NOT NULL,
    description TEXT,
    date        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- REVIEW
-- ------------------------------------------------------------
CREATE TABLE review (
    review_id  INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    rating     INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment    TEXT,
    date       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- ATTENDANCE  (warden module)
-- ------------------------------------------------------------
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT NOT NULL,
    date          DATE NOT NULL,
    status        ENUM('Present','Absent') DEFAULT 'Present',
    marked_by     VARCHAR(100),
    UNIQUE KEY uq_attendance (student_id, date),
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- VISITOR  (warden module)
-- ------------------------------------------------------------
CREATE TABLE visitor (
    visitor_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    visitor_name VARCHAR(100) NOT NULL,
    relation     VARCHAR(50),
    phone        VARCHAR(15),
    purpose      VARCHAR(150),
    entry_time   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    exit_time    TIMESTAMP NULL,
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- GALLERY  (admin-managed hostel images)
-- ------------------------------------------------------------
CREATE TABLE gallery (
    image_id    INT AUTO_INCREMENT PRIMARY KEY,
    filename    VARCHAR(255) NOT NULL,
    caption     VARCHAR(150),
    uploaded_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Rooms
INSERT INTO room (room_no, block, room_type, capacity, occupied) VALUES
('101', 'A', 'Double', 2, 2),
('102', 'A', 'Double', 2, 1),
('103', 'A', 'Single', 1, 0),
('201', 'B', 'Shared',  3, 2),
('202', 'B', 'Shared',  3, 3),
('301', 'C', 'Double',  2, 0);

-- Admin login -> username: admin   password: admin123
INSERT INTO admin (name, username, password) VALUES
('Hostel Admin', 'admin', 'scrypt:32768:8:1$ba0zshN86a3PhQwp$07c1f93f5d8c63cc9361b8f99550ecddd8c4b3de4d018d19ee8fc9866971fc13c306e4fac89179ce02e62a42b895b598dbc756d7d22c65a1f948eba1c832ec52');

-- Warden login -> username: warden   password: warden123
INSERT INTO warden (name, username, password, block) VALUES
('Ramesh Kumar', 'warden', 'scrypt:32768:8:1$fZy039rIxxkVrcb2$9402e825f422c0776753805f5226c3517c4dbd0c0f9dba7cd972f9f1c061784c1edf01487a427c04ddfe1b50c7187d61b5cbabd0c8fb84e7f35967e59297961c', 'A');

-- Students (all seeded with password: student123)
INSERT INTO student (name, roll_no, branch, year, gender, phone, email, password, room_id, hostel_block) VALUES
('Ananya Rao', 'CS101', 'CSE', '2nd Year', 'Female', '9876543210', 'ananya@example.com', 'scrypt:32768:8:1$MqEsS04M5XYm4iVV$b9043aa0bd2eaec262f110bd2d12a324b9a307c83a8eef0ead8f8932ff44022268b4dadf36e1bcceb8a6124641bfad51f969e3ff57badb22b37cccc508031b22', 1, 'A'),
('Rahul Verma', 'CS102', 'CSE', '3rd Year', 'Male', '9876543211', 'rahul@example.com', 'scrypt:32768:8:1$MqEsS04M5XYm4iVV$b9043aa0bd2eaec262f110bd2d12a324b9a307c83a8eef0ead8f8932ff44022268b4dadf36e1bcceb8a6124641bfad51f969e3ff57badb22b37cccc508031b22', 1, 'A'),
('Sneha Patil', 'EC101', 'ECE', '1st Year', 'Female', '9876543212', 'sneha@example.com', 'scrypt:32768:8:1$MqEsS04M5XYm4iVV$b9043aa0bd2eaec262f110bd2d12a324b9a307c83a8eef0ead8f8932ff44022268b4dadf36e1bcceb8a6124641bfad51f969e3ff57badb22b37cccc508031b22', 4, 'B');

-- ------------------------------------------------------------
-- DEMO LOGIN CREDENTIALS (after importing this file)
--   Admin   -> username: admin     password: admin123
--   Warden  -> username: warden    password: warden123
--   Student -> roll_no:  CS101     password: student123
-- ------------------------------------------------------------

-- Notices
INSERT INTO notice (title, description) VALUES
('Hostel Fee Deadline', 'All students must clear pending hostel fees by the 5th of next month.'),
('Water Supply Maintenance', 'Water supply in Block B will be interrupted on Saturday 9 AM–1 PM for tank cleaning.'),
('Diwali Vacation Notice', 'Hostel will remain open during vacation for students who wish to stay back. Please inform the warden in advance.');

-- Fees
INSERT INTO fee (student_id, amount, payment_date, payment_status, receipt) VALUES
(1, 25000.00, '2026-06-10', 'Paid', 'RCPT-1001'),
(2, 25000.00, NULL, 'Unpaid', NULL),
(3, 22000.00, '2026-06-15', 'Paid', 'RCPT-1002');

-- Reviews
INSERT INTO review (student_id, rating, comment) VALUES
(1, 5, 'Clean rooms and quick complaint resolution. Really comfortable stay.'),
(3, 4, 'Good food and friendly warden, water pressure could be better.');
